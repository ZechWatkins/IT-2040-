﻿using System;

namespace DogProg
{
     public enum Gender
     {
         Male,
         Female
     }
          
    public class Dog
    {
        public string name, owner ;
        
        public int age;
        public Gender gender;

        
        public string Bark()
        {
            string resp = "Woof!";
            foreach(int i in resp)
            {
                Console.Write(resp);
            }
            return (resp);
        }

        public string GetTag()
        {
            string tag = ("If lost,call" + owner+"."+ gender + "is " + age +".");
            return tag; 

        }

        
    }
    class Program
    {
        static void Main(string[] args)
        {
            Dog puppy = new Dog();
            Dog mutt;
            mutt = puppy;

            mutt = Dog("Jimbbo", "Zech", 1, Gender.Male);
            mutt.Bark();
            mutt.GetTag();



        }
    }
}
